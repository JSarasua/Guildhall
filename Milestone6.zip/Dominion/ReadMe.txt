Jonathan Sarasua
Milestone 4

AI controls
F1: Add 1 simulation
F2: Add 1000 simulations
F3: Add 1,00,000,000 simulations

//Don't use these
F4: Play best mcts move
F5: Play best big money move
//
F6: Play current AI move depending on turn
F7: Auto play game
F8: Restart game

Left,Right Arrows: Change Rollout strategy
;,': Change rollout method (Random, Heuristic, Epsilon Heuristic) The heuristic is set by the rollout strategy
z,x: Change UCB value
n,m: Change Epsilon value if doing epsilon heuristic
<,>: Change Player 1 AI Strategy
[,]: Change Player 2 AI Strategy



Play the Game:
Currently the controls pass between both players
Enter key: Move to next phase. If moving from Action to Buy phase will play all treasure cards


Buy Phase
1-8 keys: In the buy phase each key represents 1-8 of the piles you can buy in first row.
q-y keys: represent second row keys to buy

Action phase
1-9 keys: Plays that card in hand using the key as an index

Enter Key: Ends the phase