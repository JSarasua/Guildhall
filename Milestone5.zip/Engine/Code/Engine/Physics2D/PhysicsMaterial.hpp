#pragma once


struct PhysicsMaterial
{
public:
	float m_restitution = 1.f;
	float m_friction = 0.f;


public:

};