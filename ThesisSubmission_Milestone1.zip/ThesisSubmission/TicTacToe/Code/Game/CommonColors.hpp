#pragma once
#include "Engine/Renderer/RenderContext.hpp"


//Purple
Rgba8 DARKVIOLET = Rgba8( 148, 0, 211 );
Rgba8 FUCHSIA = Rgba8( 255, 0, 255 );
//Blue
Rgba8 NAVY = Rgba8( 0, 0, 128 );
Rgba8 DEEPSKYBLUE = Rgba8( 0, 191, 255 );
//Green
Rgba8 LIME = Rgba8( 0, 255, 0 );
Rgba8 SEAGREEN = Rgba8( 46, 139, 87 );
Rgba8 SPRINGGREEN = Rgba8( 0, 255, 127 );
//Red
Rgba8 SALMON = Rgba8( 250, 128, 114 );
Rgba8 CRIMSON = Rgba8( 220, 20, 60 );