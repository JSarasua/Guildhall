Jonathan Sarasua
Milestone 1

Tic Tac Toe mcts test
Use number keys 1-9 to place a circle or x. turns go back and forth
R: Restarts game