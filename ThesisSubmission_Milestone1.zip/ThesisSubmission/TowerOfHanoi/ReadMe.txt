Jonathan Sarasua
Use a combination of 1,2, and 3 to choose your move. Enter submits it.
4 runs MCTS.

Currently has bugs where it can't find the solution if too far away from it.